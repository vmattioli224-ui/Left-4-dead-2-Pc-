@echo off
chcp 65001 >nul
title Gerando L4D2Test.exe
cd /d "%~dp0"
where node >nul 2>nul || (echo Instale o Node.js LTS em https://nodejs.org e rode este arquivo de novo. & start https://nodejs.org & pause & exit /b 1)
if not exist vendor\three.min.js powershell -NoProfile -Command "Invoke-WebRequest https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js -OutFile vendor\three.min.js"
call npm install --no-audit --no-fund || (echo Falha no npm install & pause & exit /b 1)
call npx electron-packager . L4D2Test --platform=win32 --arch=x64 --out=dist --overwrite --asar=false --ignore="^/dist" --ignore="^/servidor" --ignore="^/BUILD-EXE" --ignore="^/LEIA-ME" || (echo Falha ao gerar o exe & pause & exit /b 1)
copy /y config.json "dist\L4D2Test-win32-x64\config.json" >nul
echo.
echo PRONTO! Pasta: dist\L4D2Test-win32-x64   ^(abra L4D2Test.exe^)
pause
