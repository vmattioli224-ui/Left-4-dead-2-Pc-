const { contextBridge } = require('electron');
const fs = require('fs'), path = require('path');
const root = path.join(__dirname, 'game'), clean = n => String(n).toLowerCase().replace(/[\\/]/g, '');
function config() {
  for (const p of [path.join(path.dirname(process.execPath), 'config.json'), path.join(__dirname, 'config.json')]) {
    try { return JSON.parse(fs.readFileSync(p, 'utf8')); } catch (e) { }
  }
  return {};
}
contextBridge.exposeInMainWorld('l4', {
  has: n => fs.existsSync(path.join(root, clean(n))),
  read: n => { try { return new Uint8Array(fs.readFileSync(path.join(root, clean(n)))); } catch (e) { return null; } },
  config: config()
});
