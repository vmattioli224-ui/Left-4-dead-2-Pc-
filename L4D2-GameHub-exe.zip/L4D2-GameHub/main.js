const { app, BrowserWindow, Menu } = require('electron');
const path = require('path');
['no-sandbox', 'disable-gpu-sandbox', 'ignore-gpu-blocklist', 'enable-webgl', 'in-process-gpu'].forEach(s => app.commandLine.appendSwitch(s));
app.commandLine.appendSwitch('autoplay-policy', 'no-user-gesture-required');
app.commandLine.appendSwitch('disable-features', 'CalculateNativeWinOcclusion');
Menu.setApplicationMenu(null);
if (!app.requestSingleInstanceLock()) app.quit();
app.whenReady().then(() => {
  const win = new BrowserWindow({ fullscreen: true, frame: false, show: false, backgroundColor: '#000000', autoHideMenuBar: true,
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, sandbox: false, backgroundThrottling: false } });
  win.setMenuBarVisibility(false);
  win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  win.webContents.on('will-navigate', e => e.preventDefault());
  win.webContents.on('did-finish-load', () => win.webContents.insertCSS('*,*::before,*::after{cursor:none!important}'));
  win.webContents.on('before-input-event', (e, i) => { if (i.type === 'keyDown' && i.alt && i.key === 'F4') app.quit(); });
  win.once('ready-to-show', () => { win.show(); win.setFullScreen(true); });
  win.loadFile('index.html');
});
app.on('window-all-closed', () => app.quit());
