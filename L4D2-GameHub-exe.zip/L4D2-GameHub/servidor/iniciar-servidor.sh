#!/bin/sh
cd "$(dirname "$0")"
export PORT=${PORT:-27015} FF=${FF:-0.25} MAX=${MAX:-8}
node server.js
