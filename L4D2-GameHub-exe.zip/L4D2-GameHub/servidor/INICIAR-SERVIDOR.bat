@echo off
chcp 65001 >nul
title L4D2 Test - Servidor online
set PORT=27015
set FF=0.25
set MAX=8
where node >nul 2>nul || (echo Node.js nao encontrado. Instale em https://nodejs.org & start https://nodejs.org & pause & exit /b 1)
node "%~dp0server.js"
pause
