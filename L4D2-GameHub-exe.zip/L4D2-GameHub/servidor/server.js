/* Left 4 Dead 2 Test - servidor online (sem dependências, só Node.js 16+)
   Uso:  node server.js            (porta 27015)
         PORT=8080 FF=0 node server.js
   FF = dano entre jogadores (0 = desligado, 1 = dano total). MAX = máx. de jogadores por sala. */
'use strict';
const http = require('http'), crypto = require('crypto'), os = require('os');
const PORT = +process.env.PORT || 27015, FF = process.env.FF !== undefined ? +process.env.FF : 0.25, MAX = +process.env.MAX || 8;
const GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';
const rooms = new Map();          // sala -> Map(id -> cliente)
let nextId = 1;

const server = http.createServer((req, res) => {
  const info = [...rooms].map(([n, m]) => n + ': ' + m.size + ' jogador(es)').join('\n') || 'nenhuma sala ativa';
  res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8' });
  res.end('Left 4 Dead 2 Test - servidor online ativo\nFF=' + FF + '  MAX=' + MAX + '\n\n' + info + '\n');
});

/* ---------- WebSocket (RFC 6455) mínimo ---------- */
function frame(str) {
  const p = Buffer.from(str), n = p.length;
  const h = n < 126 ? Buffer.from([0x81, n]) : n < 65536 ? Buffer.from([0x81, 126, n >> 8, n & 255]) : null;
  return h ? Buffer.concat([h, p]) : null;
}
function send(c, obj) {
  if (c.dead || c.sock.destroyed) return;
  const f = frame(typeof obj === 'string' ? obj : JSON.stringify(obj));
  if (f) c.sock.write(f);
}
function kill(c) {
  if (c.dead) return; c.dead = true;
  try { c.sock.destroy(); } catch (e) { }
  const r = rooms.get(c.room);
  if (r && r.get(c.id) === c) {
    r.delete(c.id);
    for (const o of r.values()) send(o, { t: 'leave', i: c.id });
    if (!r.size) rooms.delete(c.room);
    console.log('[-] ' + c.name + ' saiu de "' + c.room + '" (' + r.size + ' restantes)');
  }
}
function handle(c, text) {
  let m; try { m = JSON.parse(text); } catch (e) { return; }
  if (!m || typeof m.t !== 'string') return;
  if (m.t === 'join') {
    if (c.room) return;
    const room = String(m.room || 'sala1').slice(0, 24).replace(/[^\w-]/g, '') || 'sala1';
    const name = String(m.name || 'Survivor').slice(0, 16).replace(/[<>&"]/g, '') || 'Survivor';
    let r = rooms.get(room); if (!r) rooms.set(room, r = new Map());
    if (r.size >= MAX) { send(c, { t: 'full' }); return kill(c); }
    c.room = room; c.name = name; r.set(c.id, c);
    send(c, { t: 'welcome', id: c.id, ff: FF, players: [...r.values()].filter(o => o !== c).map(o => ({ i: o.id, n: o.name })) });
    for (const o of r.values()) if (o !== c) send(o, { t: 'join', i: c.id, n: name });
    console.log('[+] ' + name + ' entrou em "' + room + '" (' + r.size + ' jogadores)');
    return;
  }
  if (!c.room) return;
  const r = rooms.get(c.room); if (!r) return;
  if (m.t === 'ping') return send(c, { t: 'pong', n: m.n });
  if (m.t === 'hit') {                                   // dano: só para o alvo, escalado pelo FF do servidor
    const to = r.get(+m.to), d = Math.min(60, Math.max(0, +m.d || 0)) * FF;
    if (to && d > 0) send(to, { t: 'hit', i: c.id, d });
    return;
  }
  if (m.t === 'rev') { const to = r.get(+m.to); if (to) send(to, { t: 'rev', i: c.id }); return; }
  if (m.t === 's' || m.t === 'shot' || m.t === 'chat') {  // estado/tiro/chat: repassa a todos da sala menos o autor
    m.i = c.id; if (m.t === 'chat') m.m = String(m.m || '').slice(0, 120);
    const out = JSON.stringify(m);
    for (const o of r.values()) if (o !== c) send(o, out);
  }
}
server.on('upgrade', (req, sock) => {
  const key = req.headers['sec-websocket-key'];
  if (!key || String(req.headers.upgrade).toLowerCase() !== 'websocket') return sock.destroy();
  sock.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ' +
    crypto.createHash('sha1').update(key + GUID).digest('base64') + '\r\n\r\n');
  sock.setNoDelay(true);
  const c = { id: nextId++, sock, room: null, name: '?', dead: false, buf: Buffer.alloc(0), frag: '', tokens: 80, last: Date.now() };
  sock.on('data', d => {
    c.buf = Buffer.concat([c.buf, d]);
    if (c.buf.length > 70000) return kill(c);
    for (;;) {
      const b = c.buf; if (b.length < 2) break;
      const op = b[1] & 127; let len = op, off = 2;
      if (len === 126) { if (b.length < 4) break; len = b.readUInt16BE(2); off = 4; }
      else if (len === 127) return kill(c);              // quadros gigantes não são aceitos
      const masked = b[1] & 128; if (masked) off += 4;
      if (b.length < off + len) break;
      let p = Buffer.from(b.subarray(off, off + len));
      if (masked) for (let i = 0; i < len; i++) p[i] ^= b[off - 4 + (i & 3)];
      const opc = b[0] & 15, fin = b[0] & 128;
      c.buf = b.subarray(off + len);
      if (opc === 8) return kill(c);
      if (opc === 9) { sock.write(Buffer.concat([Buffer.from([0x8a, p.length]), p])); continue; }
      if (opc === 1 || opc === 0) {
        c.frag = opc === 1 ? p.toString() : c.frag + p.toString();
        if (c.frag.length > 4096) return kill(c);
        if (fin) {                                       // limite de mensagens por segundo (anti-flood)
          const now = Date.now(); c.tokens = Math.min(80, c.tokens + (now - c.last) * 0.06); c.last = now;
          if (c.tokens >= 1) { c.tokens--; handle(c, c.frag); }
          c.frag = '';
        }
      }
    }
  });
  sock.on('close', () => kill(c)); sock.on('error', () => kill(c));
  setTimeout(() => { if (!c.room) kill(c); }, 8000);     // quem não entra em 8s é removido
});

server.listen(PORT, '0.0.0.0', () => {
  console.log('\n=== Left 4 Dead 2 Test - servidor online ===');
  console.log('Porta: ' + PORT + '   Dano entre jogadores (FF): ' + FF + '   Máx. por sala: ' + MAX + '\n');
  console.log('Na mesma rede (Wi-Fi/LAN), seus amigos usam um destes endereços no launcher:');
  for (const l of Object.values(os.networkInterfaces()))
    for (const a of l) if (a.family === 'IPv4' && !a.internal) console.log('   ws://' + a.address + ':' + PORT);
  console.log('   ws://localhost:' + PORT + '   (neste mesmo PC)');
  console.log('\nPela internet: libere a porta ' + PORT + ' (TCP) no roteador ou use um túnel (playit.gg, ngrok, cloudflared).');
  console.log('Deixe esta janela aberta enquanto jogam.\n');
});
