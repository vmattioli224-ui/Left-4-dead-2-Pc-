/* Left 4 Dead 2 Test - multiplayer online (cliente).
   Roda depois do jogo carregar:  NET(MOD, THREE, {url:'ws://ip:27015', name:'Nick', room:'sala1'}) */
(function (root) {
  'use strict';
  function NET(MOD, T, O) {
    if (!MOD || !T || !O || !O.url || !MOD.cam || !MOD.scene) return null;
    const scene = MOD.scene, cam = MOD.cam, EYE = 1.65;
    const remotes = new Map(), hitMeshes = [], ray = new T.Raycaster();
    let ws = null, myId = 0, ff = 0, retry = 0, ping = 0, open = false, stopped = false, lastSend = 0, pingAt = 0;
    const COLORS = [0x6b7f9a, 0xa5503c, 0x5f8a4a, 0x8a5aa0, 0xc9a24a, 0x4a9a9a, 0x9a4a6a, 0x777777];

    /* ---------- HUD ---------- */
    const hud = document.createElement('div');
    hud.style.cssText = 'position:fixed;top:8px;right:10px;z-index:2147483000;font:600 12px/1.35 system-ui,sans-serif;color:#e8e4d0;text-shadow:0 1px 2px #000;text-align:right;pointer-events:none;white-space:pre';
    document.body.appendChild(hud);
    const toast = document.createElement('div');
    toast.style.cssText = 'position:fixed;top:44px;left:50%;transform:translateX(-50%);z-index:2147483000;font:600 14px system-ui,sans-serif;color:#fff;background:rgba(0,0,0,.55);padding:4px 12px;border-radius:4px;pointer-events:none;opacity:0;transition:opacity .3s';
    document.body.appendChild(toast);
    let toastT = 0; const say = m => { toast.textContent = m; toast.style.opacity = 1; clearTimeout(toastT); toastT = setTimeout(() => toast.style.opacity = 0, 2800); };
    const bar = document.createElement('div');
    bar.style.cssText = 'position:fixed;left:50%;bottom:22%;width:180px;height:8px;margin-left:-90px;z-index:2147483000;background:rgba(0,0,0,.6);border:1px solid #fff;display:none;pointer-events:none';
    bar.innerHTML = '<i style="display:block;height:100%;width:0;background:#8fd45a"></i>'; document.body.appendChild(bar);
    function drawHud() {
      const names = [...remotes.values()].map(r => '• ' + r.name + (r.down ? ' (caído)' : ''));
      hud.textContent = (open ? '● Online ' + ping + ' ms' : '○ ' + (stopped ? 'desconectado' : 'conectando…')) +
        (open ? '\n' + (remotes.size + 1) + ' jogador(es)' : '') + (names.length ? '\n' + names.join('\n') : '') + (open && ff > 0 ? '' : '');
    }

    /* ---------- avatar ---------- */
    function tag(text, color) {
      const c = document.createElement('canvas'); c.width = 256; c.height = 64; const g = c.getContext('2d');
      g.font = 'bold 34px system-ui,sans-serif'; g.textAlign = 'center'; g.lineWidth = 6; g.strokeStyle = 'rgba(0,0,0,.85)'; g.fillStyle = color || '#fff';
      g.strokeText(text, 128, 44); g.fillText(text, 128, 44);
      const tex = new T.CanvasTexture(c), sp = new T.Sprite(new T.SpriteMaterial({ map: tex, transparent: true, depthWrite: false }));
      sp.scale.set(1.6, .4, 1); return sp;
    }
    function makeAvatar(id, name) {
      const col = COLORS[id % COLORS.length], g = new T.Group(), mat = c => new T.MeshStandardMaterial({ color: c, roughness: .9 });
      const skin = mat(0xc9a07e), shirt = mat(col), pants = mat(0x34363c), dark = mat(0x1d1d1d);
      const box = (w, h, d, m, x, y, z, part) => { const b = new T.Mesh(new T.BoxGeometry(w, h, d), m); b.position.set(x, y, z); b.castShadow = true; b.userData.part = part; b.userData.rid = id; g.add(b); hitMeshes.push(b); return b; };
      const legL = box(.2, .8, .22, pants, -.13, .4, 0, 'body'), legR = box(.2, .8, .22, pants, .13, .4, 0, 'body');
      legL.geometry.translate(0, -.4, 0); legL.position.y = .8; legR.geometry.translate(0, -.4, 0); legR.position.y = .8;
      box(.5, .65, .28, shirt, 0, 1.12, 0, 'body');
      const head = new T.Mesh(new T.SphereGeometry(.15, 12, 10), skin); head.position.y = 1.62; head.userData = { part: 'head', rid: id }; head.castShadow = true; g.add(head); hitMeshes.push(head);
      box(.12, .55, .12, shirt, -.31, 1.12, -.12, 'body'); box(.12, .55, .12, shirt, .31, 1.12, -.12, 'body');
      box(.07, .12, .5, dark, .22, 1.1, -.42, 'body');           // arma
      const t = tag(name); t.position.y = 2.05; g.add(t);
      g.visible = false; scene.add(g);
      return { id, name, g, head, legL, legR, tagSp: t, x: 0, y: 0, z: 0, r: 0, p: 0, tx: 0, ty: 0, tz: 0, tr: 0, down: false, crouch: false, hp: 100, seen: 0, speed: 0, ph: 0, flash: 0 };
    }
    function addRemote(id, name) { if (id === myId || remotes.has(id)) return; remotes.set(id, makeAvatar(id, name || 'Survivor')); drawHud(); }
    function dropRemote(id) {
      const r = remotes.get(id); if (!r) return; scene.remove(r.g);
      for (let i = hitMeshes.length - 1; i >= 0; i--) if (hitMeshes[i].userData.rid === id) hitMeshes.splice(i, 1);
      r.g.traverse(o => { if (o.geometry) o.geometry.dispose(); if (o.material) { if (o.material.map) o.material.map.dispose(); o.material.dispose(); } });
      remotes.delete(id); drawHud();
    }

    /* ---------- rede ---------- */
    const tx = o => { if (open) try { ws.send(JSON.stringify(o)); } catch (e) { } };
    function connect() {
      if (stopped) return;
      try { ws = new WebSocket(O.url); } catch (e) { say('Endereço do servidor inválido'); stopped = true; drawHud(); return; }
      ws.onopen = () => { open = true; retry = 0; tx({ t: 'join', room: O.room || 'sala1', name: O.name || 'Survivor' }); drawHud(); };
      ws.onclose = () => { open = false; for (const id of [...remotes.keys()]) dropRemote(id); drawHud(); if (!stopped) setTimeout(connect, Math.min(10000, 1000 * ++retry)); };
      ws.onerror = () => { };
      ws.onmessage = e => { let m; try { m = JSON.parse(e.data); } catch (x) { return; } onMsg(m); };
    }
    function onMsg(m) {
      switch (m.t) {
        case 'welcome': myId = m.id; ff = m.ff || 0; (m.players || []).forEach(p => addRemote(p.i, p.n)); say('Conectado ao servidor' + (ff > 0 ? ' · fogo amigo ' + Math.round(ff * 100) + '%' : '')); drawHud(); break;
        case 'full': stopped = true; say('Sala cheia'); drawHud(); break;
        case 'join': addRemote(m.i, m.n); say(m.n + ' entrou'); break;
        case 'leave': { const r = remotes.get(m.i); if (r) say(r.name + ' saiu'); dropRemote(m.i); break; }
        case 'pong': ping = Math.max(0, Math.round(performance.now() - m.n)); drawHud(); break;
        case 's': {
          let r = remotes.get(m.i); if (!r) { addRemote(m.i, 'Survivor'); r = remotes.get(m.i); } if (!r) break;
          const first = !r.seen; r.seen = performance.now();
          r.tx = m.x; r.ty = Math.max(0, m.y - EYE); r.tz = m.z; r.tr = m.r; r.p = m.p || 0; r.hp = m.h; r.crouch = !!m.k;
          const wasDown = r.down; r.down = !!m.d; if (r.down !== wasDown) drawHud();
          if (first) { r.x = r.tx; r.y = r.ty; r.z = r.tz; r.r = r.tr; r.g.visible = true; }
          break;
        }
        case 'shot': { const r = remotes.get(m.i); if (r) remoteShot(r, m); break; }
        case 'hit': { try { MOD.hurt(m.d); } catch (e) { } const r = remotes.get(m.i); if (r) say(r.name + ' te acertou'); break; }
        case 'rev': { try { MOD.revive(); say((remotes.get(m.i) || {}).name + ' te reviveu'); } catch (e) { } break; }
      }
    }

    /* ---------- tiros ---------- */
    const wallDist = (o, d) => { ray.set(o, d); ray.far = 80; const h = ray.intersectObjects(MOD.hit || [], false)[0]; return h ? h.distance : 80; };
    function tracer(o, d, len) {
      const a = o.clone(), b = o.clone().addScaledVector(d, len), geo = new T.BufferGeometry().setFromPoints([a, b]);
      const l = new T.Line(geo, new T.LineBasicMaterial({ color: 0xffe9a0, transparent: true, opacity: .9 })); scene.add(l);
      setTimeout(() => { scene.remove(l); geo.dispose(); l.material.dispose(); }, 90);
    }
    function remoteShot(r, m) {
      const o = new T.Vector3(m.o[0], m.o[1], m.o[2]), d = new T.Vector3(m.d[0], m.d[1], m.d[2]).normalize();
      tracer(o.clone().addScaledVector(d, .6).add(new T.Vector3(0, -.15, 0)), d, Math.min(60, wallDist(o, d)));
      if (cam.position.distanceTo(o) < 30) try { MOD.snd.shot(); } catch (e) { }
    }
    function localShot() {
      const o = cam.position.clone(), d = new T.Vector3(); cam.getWorldDirection(d);
      tx({ t: 'shot', o: [+o.x.toFixed(2), +o.y.toFixed(2), +o.z.toFixed(2)], d: [+d.x.toFixed(3), +d.y.toFixed(3), +d.z.toFixed(3)] });
      const vis = [...remotes.values()].filter(r => r.g.visible && !r.down).length ? hitMeshes : [];
      if (!vis.length) return;
      ray.set(o, d); ray.far = 60; const h = ray.intersectObjects(vis, false)[0];
      if (h && h.distance < wallDist(o, d)) {
        const part = h.object.userData.part, id = h.object.userData.rid, r = remotes.get(id);
        tx({ t: 'hit', to: id, d: part === 'head' ? 40 : 20 }); if (r) r.flash = .25;
      }
    }

    /* ---------- reviver com E ---------- */
    let eDown = false, rvT = 0, rvId = 0;
    addEventListener('keydown', e => { if (e.code === 'KeyE') eDown = true; });
    addEventListener('keyup', e => { if (e.code === 'KeyE') eDown = false; });

    /* ---------- loop ---------- */
    let prevAmmo = MOD.ammo, prevT = performance.now();
    const tmp = new T.Vector3();
    function frame(now) {
      if (stopped && !open && !remotes.size) { return; }
      requestAnimationFrame(frame);
      const dt = Math.min(.1, (now - prevT) / 1000); prevT = now;
      /* detectar tiro local (munição caiu 1) */
      const am = MOD.ammo; if (am === prevAmmo - 1 && !MOD.dead) localShot(); prevAmmo = am;
      /* enviar meu estado ~20x/s */
      if (open && now - lastSend > 50) {
        lastSend = now; const p = cam.position;
        tx({ t: 's', x: +p.x.toFixed(2), y: +p.y.toFixed(2), z: +p.z.toFixed(2), r: +cam.rotation.y.toFixed(3), p: +cam.rotation.x.toFixed(3), h: Math.round(MOD.hp || 0), d: MOD.down ? 1 : 0, k: MOD.crouch > .5 ? 1 : 0 });
      }
      if (open && now - pingAt > 2000) { pingAt = now; tx({ t: 'ping', n: performance.now() }); }
      /* suavizar jogadores remotos */
      const k = 1 - Math.exp(-dt * 14); let near = null, nd = 2.4;
      for (const r of remotes.values()) {
        if (!r.seen) continue;
        if (now - r.seen > 5000) { r.g.visible = false; continue; } r.g.visible = true;
        const px = r.x, pz = r.z;
        r.x += (r.tx - r.x) * k; r.y += (r.ty - r.y) * k; r.z += (r.tz - r.z) * k;
        let dr = r.tr - r.r; dr = Math.atan2(Math.sin(dr), Math.cos(dr)); r.r += dr * k;
        r.speed += ((Math.hypot(r.x - px, r.z - pz) / Math.max(dt, 1e-3)) - r.speed) * .2; r.ph += dt * Math.min(9, r.speed * 2.2);
        const g = r.g; g.position.set(r.x, r.y, r.z); g.rotation.y = r.r;
        const sw = r.down ? 0 : Math.sin(r.ph) * Math.min(.7, r.speed * .15); r.legL.rotation.x = sw; r.legR.rotation.x = -sw;
        r.head.rotation.x = r.p * .6;
        if (r.down) { g.rotation.x = -1.35; g.position.y = r.y + .3; g.position.z = r.z; } else { g.rotation.x = 0; g.scale.y = r.crouch ? .8 : 1; }
        r.flash = Math.max(0, r.flash - dt);
        r.tagSp.material.color.setHex(r.flash > 0 ? 0xff6060 : r.down ? 0xff9090 : 0xffffff);
        if (r.down && !MOD.down) { const d = Math.hypot(r.x - cam.position.x, r.z - cam.position.z); if (d < nd) { nd = d; near = r; } }
      }
      /* segurar E perto de um caído para reviver */
      if (near && eDown && open) { if (rvId !== near.id) { rvId = near.id; rvT = 0; } rvT += dt; bar.style.display = 'block'; bar.firstChild.style.width = Math.min(100, rvT / 2.2 * 100) + '%'; if (rvT >= 2.2) { tx({ t: 'rev', to: near.id }); rvT = 0; } }
      else { rvT = 0; bar.style.display = 'none'; }
    }
    requestAnimationFrame(frame);
    drawHud(); connect();
    return { stop() { stopped = true; try { ws.close(); } catch (e) { } hud.remove(); toast.remove(); bar.remove(); for (const id of [...remotes.keys()]) dropRemote(id); } };
  }
  root.L4D2_NET = NET;
})(typeof window !== 'undefined' ? window : globalThis);
